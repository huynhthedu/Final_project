from django import forms
from .models import Evaluation, Institution

class EvaluationForm(forms.ModelForm):
    institution = forms.ModelChoiceField(
    queryset=Institution.objects.all(),
    label="Choose Institution",
    initial=Institution.objects.get(instnm="Indiana University-Bloomington")
    )
    grade = forms.ChoiceField(choices=[(str(i), str(i)) for i in range(1, 8)], label="Grade")

    class Meta:
        model = Evaluation
        fields = ['institution', 'comments', 'grade', 'unitid', 'instnm']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['unitid'] = forms.CharField(widget=forms.HiddenInput(), required=False)
        self.fields['instnm'] = forms.CharField(widget=forms.HiddenInput(), required=False)

    def clean(self):
        cleaned_data = super().clean()
        institution = cleaned_data.get('institution')
        if institution:
            cleaned_data['unitid'] = institution.unitid
            cleaned_data['instnm'] = institution.instnm
        return cleaned_data


class EvaluationEditForm(forms.ModelForm):
    class Meta:
        model = Evaluation
        fields = [ 'unitid', 'instnm', 'comments', 'grade'] 

