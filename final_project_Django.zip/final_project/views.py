from django.shortcuts import render, redirect, get_object_or_404
from data.models import State, Sector 
from .models import LibraryD, Instructional_D, Instructional, Tenure_D, InstitutionTenure, Library, Institution, Instruction, Library_data, Faculty, Institutions, Evaluation
from django.db.models import Sum
import pandas as pd
import logging
from django.http import JsonResponse
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderUnavailable
from django.db.models import IntegerField
from django.db.models.functions import Cast
import time
import matplotlib.pyplot as plt
from django.http import HttpResponse
from io import BytesIO
import base64
from django.template.defaultfilters import floatformat
from django.contrib.humanize.templatetags.humanize import intcomma
import zipfile
import io
import requests
import numpy as np
from django.core.cache import cache
from django.shortcuts import render, redirect, get_object_or_404
from .forms import EvaluationForm, EvaluationEditForm
from django.contrib import messages
from django.views.decorators.http import require_POST
import plotly.express as px


def visualization(request):
    institutions = Institution.objects.all().values()
    items = LibraryD.objects.all().values()
    institutions_list = list(institutions)   

    default_instnm = "Indiana University-Bloomington"
    selected_instnm = request.GET.get("institution", default_instnm)
    start_year = int(request.GET.get("start_year", 2022))
    end_year = int(request.GET.get("end_year", 2023))
    years = range(start_year, end_year +1)
    years = [str(year) for year in years]

    default_item_name = "Digital/electronic databases"
    selected_item = request.GET.get("item_id", default_item_name)

    library_data = Library_data.objects.all().values()
    library_df = pd.DataFrame(list(library_data))   
    # print(library_df)
    aggregated_df = library_df.groupby(['item', 'year', 'state', 'sector'])['value'].sum().reset_index()
    # print(aggregated_df.head())

    # Filter institutions DataFrame
    institutions_df = pd.DataFrame(institutions_list)
    selected_inst = institutions_df[institutions_df["instnm"] == selected_instnm]
    # print(selected_inst)
    if selected_inst.empty:
        return JsonResponse({"error": "Institution not found"}, status=404)

    unitid = (selected_inst["unitid"].values[0])
    # print(unitid)
    sector = selected_inst["sector"].values[0]
    state = selected_inst["stabbr"].values[0]
    # print(years)

    # Filter library DataFrame
    library_filtered = library_df[(library_df['unitid'] == unitid) & (library_df['year'].isin(years))]
    # faculty_filtered = faculty_df[(faculty_df['unitid'] == unitid) & (faculty_df['year'].isin(years))]
    # print(library_filtered.head())
    # print(faculty_filtered.head())
    
    # Check for duplicates in the columns used for pivot
    duplicates = library_filtered[library_filtered.duplicated(['institution', 'year'], keep=False)]
    # print("Duplicates:")
    # print(duplicates)

    # Remove duplicates or aggregate them
    # library_filtered = library_filtered.drop_duplicates(subset=['institution', 'year'])

    # Pivot the DataFrame using pivot_table with an aggregation function
    library_pivot = library_filtered.pivot_table(index=['institution', 'item'], columns='year', values='value', aggfunc='sum')

    # print("Pivoted DataFrame:")
    # print(library_pivot)

    library_pivot.reset_index(inplace=True)
    library_dict = library_pivot.to_dict(orient='records')
    # faculty_dict = faculty_filtered.to_dict(orient='records')
    # print(library_dict)
    # print(faculty_dict)
    
    
    # Filter library DataFrame for the selected item
    item_filtered_df = library_filtered[library_filtered['item'] == selected_item]

    # Generate bar chart for the selected item by years with the selected institution
    
    plt.figure(figsize=(10, 6))

    plt.bar(item_filtered_df['year'], item_filtered_df['value'])

    plt.xlabel('Year')
    plt.ylabel('Value')
    plt.title(f'Bar Chart for {selected_item} by Years for Institution: {selected_instnm}')
    plt.xticks(rotation=45)
    
    # Save the plot to a BytesIO object
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    string = base64.b64encode(buf.read())
    uri = 'data:image/png;base64,' + string.decode('utf-8')


    return render(request, "final_project/visualization.html", {
        "institutions": institutions_list,
        "selected_institution": selected_instnm,
        "library": library_dict,
        "years_range": range(2019, 2023),
        "years_reverse_range": range(2023, 2019, -1),
        "start_year": start_year,
        "end_year": end_year,
        "selected_item": selected_item,        
        "items": items,
        "chart": uri,
    })

def aggregation(request):
    library_data = Library_data.objects.all().values()
    library_df = pd.DataFrame(list(library_data))
    library_df = library_df[(library_df['item'] != "Expenditures")]

    if library_df.empty:
        return HttpResponse("No data available.")

    # Cast year to int
    library_df['year'] = library_df['year'].astype(int)

    agg_item = library_df.groupby(['item', 'year'])['value'].sum().reset_index()
    agg_state = library_df.groupby(['stabbr', 'year'])['value'].sum().reset_index()
    

    years = sorted(agg_item['year'].unique())
    selected_year = int(request.GET.get('year', years[0]))

    item_year = agg_item[(agg_item['year'] == selected_year)]
    state_year = agg_state[(agg_state['year'] == selected_year)]

    fig_item = px.treemap(
    item_year,
    path=['item'],
    values='value',
    title=f'Library Collections by Types in {selected_year}',
    )
  
    fig_item.update_traces(textinfo='label+value')

    chart_item = fig_item.to_html(full_html=False)

    fig_state = px.treemap(
    state_year,
    path=['stabbr'],
    values='value',
    title=f'Library Collections by States in  {selected_year}',
    )
  
    fig_state.update_traces(textinfo='label+value')

    chart_state = fig_state.to_html(full_html=False)

    return render(request, 'final_project/aggregation.html', {
        'chart_item': chart_item,
        'chart_state': chart_state,
        'years': years,
        'selected_year': selected_year,
    })


def create_evaluation(request):
    if request.method == 'POST':
        form = EvaluationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('evaluation_success')
    else:
        form = EvaluationForm()
    return render(request, 'final_project/create_evaluation.html', {'form': form})

def evaluation_success(request):
    return render(request, 'final_project/evaluation_success.html')

def edit_success(request):
    return render(request, 'final_project/edit_success.html')


def edit_evaluation(request, pk):
    # Fetch the Evaluation object using the pk
    evaluation = get_object_or_404(Evaluation, pk=pk)

    if request.method == 'POST':
        # Check if the delete button was pressed
        if 'delete' in request.POST:
            evaluation.delete()
            messages.success(request, "Evaluation deleted successfully!")  # Add a success message
            return redirect('edit_list')  # Redirect to the edit list page
        
        # Handle form submission for saving the edited evaluation
        form = EvaluationEditForm(request.POST, instance=evaluation)
        if form.is_valid():
            form.save()  # This will update the 'updated_at' field automatically
            messages.success(request, "Evaluation updated successfully!")  # Success message
            return redirect('edit_success')  # Redirect to a success page
    else:
        # If it's a GET request, initialize the form with the existing data
        form = EvaluationEditForm(instance=evaluation)

    # Render the edit page with the form and evaluation details
    return render(request, 'final_project/edit_evaluation.html', {
        'form': form,
        'evaluation': evaluation
    })

def evaluation_list(request):
    evaluations = Evaluation.objects.all()
    return render(request, 'final_project/edit_list.html', {'evaluations': evaluations})

from django.contrib import messages

@require_POST
def delete_evaluation(request, pk):
    evaluation = get_object_or_404(Evaluation, pk=pk)
    evaluation.delete()
    messages.success(request, 'Evaluation deleted successfully.')
    return redirect('edit_list')


def final_project(request):
    return render(request, 'final_project/final_project.html')