from django.db import models

# Create your models here.

class Instruction(models.Model):
    id = models.AutoField(primary_key=True)
    unitid = models.TextField(db_column='UNITID', blank=True, null=True)  # Field name made lowercase.
    arank = models.TextField(db_column='ARANK', blank=True, null=True)  # Field name made lowercase.
    year = models.BigIntegerField(db_column='Year', blank=True, null=True)  # Field name made lowercase.
    item = models.TextField(db_column='Item', blank=True, null=True)  # Field name made lowercase.
    value = models.FloatField(db_column='Value', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'instruction'

class Instructional(models.Model):
    varname = models.BigAutoField(primary_key=True)
    Instructional_id = models.CharField(max_length=100)
    Gender_ID = models.CharField(max_length=100)
    Duration_ID = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'instructional'

class Instructional_D(models.Model):
    Instructional_id = models.BigAutoField(primary_key=True)
    varTitle = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'instructional_id'

class Institution(models.Model):
    instnm = models.TextField(blank=True, null=True)
    unitid = models.IntegerField(blank=True, null=False, unique=True, primary_key=True)    
    stabbr = models.TextField(blank=True, null=True)   
    sector = models.IntegerField(blank=True, null=True)
    class Meta:
        managed = False
        db_table = 'institution'

    def __str__(self):
        # Return a string that includes both unitid and instnm
        return f"{self.unitid} - {self.instnm}"


class Library(models.Model):
    id = models.AutoField(primary_key=True)
    unitid = models.TextField(db_column='UNITID', blank=True, null=True)  # Field name made lowercase.
    lcolelyn = models.TextField(db_column='LCOLELYN', blank=True, null=True)  # Field name made lowercase.
    year = models.BigIntegerField(db_column='Year', blank=True, null=True)  # Field name made lowercase.
    item = models.TextField(db_column='Item', blank=True, null=True)  # Field name made lowercase.
    value = models.FloatField(db_column='Value', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'library'


class LibraryD(models.Model):
    lb_id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'library_D'

class Tenure_D(models.Model):
    Tenure_ID = models.BigAutoField(primary_key=True)
    Tenure = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'tenure_id'

class InstitutionTenure(models.Model):
    id = models.BigAutoField(primary_key=True)
    institution = models.ForeignKey(
        'data.Insitution',    # Adjust the model path as needed
        on_delete=models.CASCADE,
        db_column='unitid'
    )
    tenure = models.ForeignKey(
        Tenure_D,
        on_delete=models.CASCADE,
        db_column='Tenure_ID'
    )
    year = models.CharField(max_length=10)
    value = models.CharField(max_length=100)

    class Meta:
        db_table = 'institution_tenure'


from django.db import models

class Library_data(models.Model):
    id = models.BigAutoField(primary_key=True)
    unitid = models.IntegerField()
    item = models.CharField(max_length=255)
    year = models.IntegerField()
    value = models.FloatField()
    institution = models.CharField(max_length=255)
    stabbr = models.CharField(max_length=2)
    state = models.CharField(max_length=255)
    sector = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'library_view'


class Faculty(models.Model):
    id = models.AutoField(primary_key=True)
    gender = models.CharField(max_length=15)
    institution = models.CharField(max_length=100)
    item = models.CharField(max_length=100)
    sector = models.CharField(max_length=50)
    stabbr = models.CharField(max_length=2)
    state = models.CharField(max_length=50)
    tenure = models.CharField(max_length=50)
    unitid = models.CharField(max_length=15)
    value = models.DecimalField(max_digits=10, decimal_places=2)
    year = models.CharField(max_length=4)

    class Meta:
        managed = False
        db_table = 'faculty_view'


class Institutions(models.Model):
    unitid = models.CharField(max_length=20, primary_key=True)
    instnm = models.CharField(max_length=255)
    comments = models.TextField(blank=True, null=True)  # 🆕 Added
    grade = models.CharField(max_length=5, blank=True, null=True)  # 🆕 Added

    def __str__(self):
        return self.instnm
    

class Evaluation(models.Model):    
    unitid = models.IntegerField()
    instnm = models.CharField(max_length=255)
    comments = models.TextField(blank=True, null=True)  
    grade = models.CharField(max_length=5, blank=True, null=True)  
    created_at = models.DateTimeField(auto_now_add=True)      
    updated_at = models.DateTimeField(auto_now=True)  

    def __str__(self):
        return self.instnm

