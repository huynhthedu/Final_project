from django.urls import path
from . import views
from .views import create_evaluation
from django.views.generic import TemplateView


urlpatterns = [
    path('', views.final_project, name='final_project'),
    # path('add/', views.institution_create, name='institution-create'),
    # path('edit/<str:pk>/', views.institution_update, name='institution-update'),
    # path('', views.resources, name='resources'),  # Make sure this matches the URL you want
    # path('institution_tenure_crud/', views.institution_tenure_crud, name='institution_tenure_crud'), 
    path('visualization/', views.visualization, name='visualization'),     
    path('create-evaluation/', create_evaluation, name='create_evaluation'),
    path('evaluation-success/', TemplateView.as_view(template_name='final_project/evaluation_success.html'), name='evaluation_success'),
    path('edit-success/', TemplateView.as_view(template_name='final_project/edit_success.html'), name='edit_success'),
    # path('edit-evaluation/<int:pk>/', views.edit_evaluation, name='edit_evaluation'),
    path('edit-list/', views.evaluation_list, name='edit_list'),
    path('edit-evaluation/<int:pk>/', views.edit_evaluation, name='edit_evaluation'),
    path('final_project/delete-evaluation/<int:pk>/', views.delete_evaluation, name='delete_evaluation'),
     path('aggregation/', views.aggregation, name='aggregation'),

]
