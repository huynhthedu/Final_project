from django.core.management.base import BaseCommand
import pandas as pd
from final_project.models import Institution

class Command(BaseCommand):
    help = 'Load institutions from Institution.csv into the database'

    def handle(self, *args, **kwargs):
        file_path = 'final_project/Institution.csv'
        try:
            df = pd.read_csv(file_path, encoding='ISO-8859-1')

            for _, row in df.iterrows():
                Institution.objects.update_or_create(
                    unitid=row['UNITID'],
                    defaults={
                        'instnm': row['INSTNM'],
                        'city': row['CITY'],
                        'stabbr': row['STABBR'],
                        'zip': row['ZIP'],
                    }
                )

            self.stdout.write(self.style.SUCCESS('Successfully loaded Institutions from Institution.csv'))
        except Exception as e:
            self.stderr.write(self.style.ERROR(f'Error: {e}'))